let tedi = 50*0.9;
let nikoleta = 100*0.95;
sumOfTediAndNikoleta = tedi+nikoleta;
let radi = 30;
let ivo = 20;
sumOfRadiAndIvo = (radi+ivo)*5/6;

let highestPoints = [tedi, nikoleta, radi, ivo];

console.log("Highest Points: " + Math.max(highestPoints[0],highestPoints[1],highestPoints[2],highestPoints[3]));



function winners(sumOfTediAndNikoleta,sumOfRadiAndIvo){
    if(sumOfTediAndNikoleta>sumOfRadiAndIvo){
        return "GIRLS POWER"
    }if (sumOfTediAndNikoleta<sumOfRadiAndIvo){
        return "MANS POWER";
    } else(sumOfTediAndNikoleta===sumOfRadiAndIvo)
        return "EQUAL POINTS";


}

console.log(winners(sumOfTediAndNikoleta,sumOfRadiAndIvo));

function DifferenceBetweenPoints(sumOfTediAndNikoleta, sumOfRadiAndIvo){
    if(sumOfTediAndNikoleta>sumOfRadiAndIvo){
        return sumOfTediAndNikoleta-sumOfRadiAndIvo;
    }else
        return sumOfRadiAndIvo-sumOfTediAndNikoleta;
}
console.log ("Difference between points: "+ Math.ceil(DifferenceBetweenPoints(sumOfTediAndNikoleta, sumOfRadiAndIvo)));
