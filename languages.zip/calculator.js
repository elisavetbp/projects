let language = "bulgarian";
function decodeSelector(encoded) {
    var elem = document.createElement('textarea');
    elem.innerHTML = encoded;
    var decoded = elem.value;
    return decoded;
}

function getSelector(attr) {
    var xType = attr.localName;
    var xSelect = attr.nodeValue;

    switch (xType) {
        case "class":
        case "targetclass":
            xSelect = "." + xSelect;
            break;
        case "id":
        case "targetid":
            xSelect = "#" + xSelect;
            break;
        case "customAttribute":
            var s = xSelect.split(",");
            xSelect = "[" + s[0] + "='" + decodeSelector(s[1]) + "']";
            break;
        case "custom":
            xSelect = decodeSelector(xSelect);
            break;
        default:
            xSelect = "";
            break;
    }
    return xSelect;
}

function setTarget(targetPick, languageText) {
    var attrs = targetPick.attributes;
    for (var j = 0; j < attrs.length; j++) {
        var xSelect = getSelector(attrs[j]);
        if (xSelect) {
            var target = $(xSelect);
            target.text(languageText);
        }
    }
}

$(function() {
    $(xmlDoc).find('translation').each(function() {
        var targetTranslation = $(this).find(language);
        var text = targetTranslation.text();
        setTarget(this, text);
    });
});